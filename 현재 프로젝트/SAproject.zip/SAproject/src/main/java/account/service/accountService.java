package account.service;

import java.util.List;

import account.dto.member;

public interface accountService {
	public List<member> show();
}
