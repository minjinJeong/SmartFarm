package account.dao;

import java.util.List;

import account.dto.member;

public interface accountDao {
	List<member> show();
}
